# Import
from flask import Flask, render_template,request, redirect



app = Flask(__name__)

# İçerik sayfasını çalıştırma
@app.route('/')
def index():
    return render_template('index.html')


# Form işleme
@app.route('/', methods=['POST'])
def process_form():

    girilen_email = request.form.get('email')
    girilen_yazi = request.form.get('text')

    with open('feedback.txt', 'a', encoding='Utf-8') as dosya:
        dosya.write(f"Email: {girilen_email}\n")
        dosya.write(f"Yorum: {girilen_yazi}\n")
        dosya.write("-" *50 + '\n')
    # Buraya kodunuzu yazın
    return render_template('index.html')


if __name__ == "__main__":
    app.run(debug=True)
